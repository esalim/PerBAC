-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 30 juil. 2019 à 07:42
-- Version du serveur :  10.1.38-MariaDB
-- Version de PHP :  7.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `smartparking`
--
CREATE DATABASE IF NOT EXISTS `smartparking` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `smartparking`;

-- --------------------------------------------------------

--
-- Structure de la table `dispo`
--

CREATE TABLE `dispo` (
  `id` int(11) NOT NULL,
  `place` varchar(255) NOT NULL,
  `etat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `dispo`
--

INSERT INTO `dispo` (`id`, `place`, `etat`) VALUES
(1, 'place 1', 'dispo'),
(2, 'place 2', 'ndispo'),
(3, 'place 3', 'ndispo'),
(4, 'place 4 ', 'dispo'),
(5, 'place 5', 'dispo'),
(6, 'place 6', 'dispo'),
(7, 'place 7', 'ndispo'),
(8, 'place 8', 'ndispo'),
(9, 'place 9', 'dispo'),
(10, 'place 10', 'ndispo'),
(11, 'place 11', 'dispo'),
(12, 'place 12', 'dispo'),
(13, 'place 13', 'ndispo'),
(14, 'place 14', 'ndispo'),
(15, 'place 15', 'dispo');

-- --------------------------------------------------------

--
-- Structure de la table `permission`
--

CREATE TABLE `permission` (
  `id` int(11) NOT NULL,
  `nomOrga` varchar(255) NOT NULL,
  `nomUser` varchar(255) NOT NULL,
  `poste` varchar(255) NOT NULL,
  `badge` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `autorisation` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `permission`
--

INSERT INTO `permission` (`id`, `nomOrga`, `nomUser`, `poste`, `badge`, `action`, `autorisation`) VALUES
(1, 'MIT', 'AbdramCoulby', 'Administrateur', 'Rouge', 'acceder', 'oui'),
(2, 'MIT', 'Hamed', 'Administrateur', 'Rouge', 'acceder', 'non'),
(3, 'Azure', 'Admin', 'Administrateur', 'Rouge', 'acceder', 'oui'),
(4, 'MIT', 'Mamadou', 'Developpeur', 'Bleu', 'acceder', 'oui'),
(5, 'MIT', 'Hawa', 'Developpeur', 'Bleu', 'acceder', 'non'),
(6, 'Azure', 'Moustapha', 'Developpeur', 'Bleu', 'acceder', 'oui'),
(7, 'MIT', 'Mariam', 'Secretaire', 'Bleu', 'acceder', 'oui'),
(8, 'MIT', 'Habiba', 'Secretaire', 'Bleu', 'acceder', 'non');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `fonction` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `username`, `fonction`, `password`) VALUES
(1, 'AbdramCoulby', 'Administrateur', '$2y$10$eRPutxvh.XE2GFXYbJdjIui0mLwVtuuLrkPyhrYShzJRYopZEk0OO'),
(2, 'testeur', 'Developpeur', '$2y$10$O4CpkZ1W/UHfuZ2Bl5sodOQ/BC.RgOmedyPmpr4BwX5nfxSQBWa4a'),
(5, 'abc', 'Dev', '$2y$10$xNseBv9wH3bcdUD8tpRuh.UV6TzuJJiV.a1O.lqUgi3uk7NhBKlU6');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `dispo`
--
ALTER TABLE `dispo`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `dispo`
--
ALTER TABLE `dispo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `permission`
--
ALTER TABLE `permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
